//Rohan Patel
//Shane Padefield

package com.example.rohan.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    String value;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView tv = (TextView) findViewById(R.id.textViewSelectShape);
        final TextView result = (TextView) findViewById(R.id.textViewResult);

        findViewById(R.id.imageViewTriangle).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setText("Triangle");
                findViewById(R.id.textViewLength2).setVisibility(View.VISIBLE);
                findViewById(R.id.editTextLength2).setVisibility(View.VISIBLE);
                value = "Triangle";
            }
        });
        findViewById(R.id.imageViewSquare).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setText("Square");
                findViewById(R.id.textViewLength2).setVisibility(View.INVISIBLE);
                findViewById(R.id.editTextLength2).setVisibility(View.INVISIBLE);
                value = "Square";
            }
        });
        findViewById(R.id.imageViewCircle).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setText("Circle");
                findViewById(R.id.textViewLength2).setVisibility(View.INVISIBLE);
                findViewById(R.id.editTextLength2).setVisibility(View.INVISIBLE);
                value = "Circle";
            }
        });

        Button btn = (Button) findViewById(R.id.buttonCalculate);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (value == "Triangle")
                {
                    EditText et1 = (EditText) findViewById(R.id.editTextLength1);
                    EditText et2 = (EditText) findViewById(R.id.editTextLength2);

                    double length1 = Double.parseDouble(et1.getText().toString());
                    double length2 = Double.parseDouble(et2.getText().toString());

                    Double aot = 0.5 * length1 * length2;

                    result.setText(aot + "");
                }
                else if (value == "Square")
                {
                    EditText et1 = (EditText) findViewById(R.id.editTextLength1);

                    double length1 = Double.parseDouble(et1.getText().toString());

                    Double aos = length1 * length1;

                    result.setText(aos + "");

                }
                else if (value == "Circle")
                {
                    EditText et1 = (EditText) findViewById(R.id.editTextLength1);

                    double length1 = Double.parseDouble(et1.getText().toString());

                    Double aoc = 3.1416 * length1 * length1;

                    result.setText(aoc + "");
                }
            }
        });

        findViewById(R.id.buttonClear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = getIntent();
                finish();
                startActivity(intent);
            }
        });
    }


}
